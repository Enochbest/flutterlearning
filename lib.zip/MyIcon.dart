import 'package:flutter/material.dart';
class MyIcons{
  static const IconData book = IconData(
      0xf00a1,
      fontFamily: "MyIcon",
      matchTextDirection: true
  );
  static const IconData weixin = IconData(
      0xf0106,
      fontFamily: "MyIcon",
      matchTextDirection: true
  );
  static const IconData users = IconData(
      0xe787,
      fontFamily: "MyIcon",
      matchTextDirection: true
  );
  static const IconData category = IconData(
      0xe62f,
      fontFamily: "MyIcon",
      matchTextDirection: true
  );
}
